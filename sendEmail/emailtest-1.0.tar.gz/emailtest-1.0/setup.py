#coding:utf8
from setuptools import setup

setup(
    name="emailtest",
    version="1.0",
    packages=["emailtest"]
)
